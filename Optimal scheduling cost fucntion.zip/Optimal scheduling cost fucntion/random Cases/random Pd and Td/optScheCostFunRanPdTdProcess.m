clc, clear;

load('parExactSolRandomPdTd.mat');

n = 50;
Ts = 4;
infoTs = Ts + 1;

raizN = (n)^(1/2);
nivelCon = 0.95;
alpha = 1-nivelCon;
z = norminv(1-(alpha/2));

aux = 1;
temp = 0;
temp = zeros(50,3);
auxVal = zeros(1,3);
meanVal = [];
stdVal = [];

for j = 1:infoTs
    aux = j;
    for i = 1:50
        temp(i,:) = parExactSolRandomPdTd(aux,3:end);
        aux = aux + 5;
    end
    auxMean = mean(temp);
    auxStd = std(temp);
    
    meanVal = [meanVal;auxMean];
    stdVal = [stdVal; auxStd];
end

%---Median values
%meanVal

%---Standard deviations
%stdVal

%---Confidence intervals

[rStdVal, cStdVal] = size(stdVal);
intervalConf = zeros(rStdVal, cStdVal);

for i = 1:rStdVal  %rows
    for j = 1:cStdVal %columns
        intervalConf(i,j) = (stdVal(i,j)*z)/(raizN);
    end
end
%intervalConf