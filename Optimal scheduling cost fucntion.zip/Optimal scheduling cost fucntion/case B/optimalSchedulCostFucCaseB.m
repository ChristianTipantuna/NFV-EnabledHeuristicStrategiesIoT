% -------------------------------------------------------------------------
%Universidad Politecnica de Catalunya (UPC)
%Doctoral Program in Computer Networks
%Author: Christian Tipantuna
%Advisor: Dr. Xavier Hesselbach
%Date: July 2019
%Description: Energy-aware scheduling of services considering the
%minimization of a residual power and respecting the objective function
%which consists of the minimization of the associated cost in the
%allocation
%This scheduling provides the optimal result and it has been proven be
%NP-Hard.
%Strategy: Greedy Algorithm inspired in recursive solution of a knapsack
%problem
%Apendix: Combinatorial theory:
%http://momrach.es/wp-content/uploads/2009/04/combinatoria-con-matlab-univigo.pdf
% -------------------------------------------------------------------------

%--- System parameters:
%   Power from energy supplier              Pes>0
%   Number of services (demands or jobs):   n, k = 1,...,n
%   Priority identifier:                    lk = 1
%   Power demanded by services:             uk = 1
%   Lifetime duration of demands:           dk = 1,2,3,4
%   Time shifting performed:                mts = 0,1,2,3,4
%   Maximum time horizon:                   tmax = 8
%   Time window of energy supplier          tpes = 5
%   Cost function:                          ck = car + cl + cmts
%                                           alternatively
%                                           ck = 1/2(3) ck (related to the
%                                           error square)
%--- Performance metrics:
%Residual power:                            Pres
%Acceptance ratio:                          AR
%Power to process AR=100%:                  Plack

%--- Algorithm:
%Order by priority
%Choose the services in order (id)
%

% -------------------------------------------------------------------------
%Tests:
%-Different number of generations = 1,2,3...,5
%-Different size of
% -------------------------------------------------------------------------


clc, clear, close all;

tic;

%--- Initialization of arrays to store variables
timeShiftingInfo = []; %value of time shifting of services
timeDurationInfo = []; %values of lifetime of services
resPowCombVarInfo = []; %values of residual power of the best combinations
arCombVarInfo = []; %values of acceptance ratio of the best combinations
lackPowCombVarInfo = []; %values of missing power of the best combinations

numberVariationsInfo = []; %information about the number of variations
runningTimeInfo = []; %running time per each case (Mts and dk)

iterCaseInfo = []; %values of the number of iterations

%--------------------------------------------------------------------------
% Parameters of the system
%--------------------------------------------------------------------------

for iterCase = 1:50 %iterations for IterCase %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    for iterTd = 1:3 %3 %iterations for Td %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        mVal = [4,8,12]; %variable to be used to allocate the energy demands

        for iterTs = 0:6 %0:1 %iterations for Ts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            tStartCase = tic; %initial time to per case
            
            %--- Power from energy supplier
            PesValue = 2;
            
            %--- Number of services/demands/jobs
            n = 8;
            
            auxMaxTs = 4; %auxiliar variable for Case A
            
            %--- Maximum value of time shifting
            maxTs = iterTs;
            
            %--------------------------------------------------------------------------
            % Parameters of services (power demands)
            %--------------------------------------------------------------------------
            
            %Services: Service identifier, priority, power demand, start time, duration,
            %time shifting
            %Fields: sk, lk, uk, tinitk, dk, mts_min, mts_max
            services = zeros(n,7); %7 number of parameters
            
            
            %--- Number of services: sk
            %servicesSk = [1 2 3 4 5]
            for i = 1:n
                services(i,1) = i; %servicesSk(i);
            end
            
            %--- Priority of the service: lk
            %serviceslk = [1 2 2 3 3 3];
            for i = 1:n
                services(i,2) = 1;%serviceslk(i); %4;
            end
            
            %--- Power demand by services: uk (fixed value = 2 power units)
            %servicesUk = [1 1 1 1 1];
            %servicesUk = [3 2];
            for i = 1:n
                services(i,3) = 1; %servicesUk(i); %1; %powerDemandedValue; %1; %servicesUk(i);
            end
            
            %--- Start time of services: tinitk
            %servicesTinitk = [auxMaxTs auxMaxTs auxMaxTs auxMaxTs+iterTd auxMaxTs+iterTd auxMaxTs+iterTd];
            %demandsTinit = [0 0 0 0 iterTd+mVal(iterTd) iterTd+mVal(iterTd) iterTd+mVal(iterTd) iterTd+mVal(iterTd)];
            %servicesTinitk = [1 4];
            demandsTinit = [0 0 0 0 iterTd+mVal(iterTd) iterTd+mVal(iterTd) iterTd+mVal(iterTd) iterTd+mVal(iterTd)];
            for i = 1:n
                services(i,4) = demandsTinit(i); %i-1; %servicesTinitk(i); %i-1; %servicesTinitk(i); %i-1; %servicesTinitk(i);
            end
            
            %--- Life time of services: dk
            %servicesDk = [1 1 1 1 1];
            %servicesDk = [1 2];
            for i = 1:n
                services(i,5) = iterTd; %2; %servicesDk(i); %2; %iterTd; %servicesDk(i);
            end
            
            %--- Time Shifting(time shifting backward): mts_min
            %servicesMts_min = [1 1 1 1 1];
            for i = 1:n
                services(i,6) = maxTs; %1; %iterTs;%0; %servicesMts_min(i);
            end
            
            %--- Time Shifting(time shifting forward): mts_max
            %servicesMts_max = [1 1 1 1 1];
            for i = 1:n
                services(i,7) = maxTs; %1; %iterTs;%0; %servicesMts_max(i);
            end
            
            
            %--------------------------------------------------------------------------
            % Computation of time variable - tmax a.k.a the maximum time horizon
            %--------------------------------------------------------------------------
            
            maxTinit = max(services(:,4));  %maximum value of the starting time (last demand)
            maxD = max(services(:,5));      %maximum value of the longest demand
            maxMTs = max(services(i,7));    %maximum valuer of forward time shiting
            
            %tmax = (n-1) + timeDurDemand + timeShifDur;
            tmax = maxTinit + maxD + maxMTs;  %maximum time horizon for simulation
            
            
            %--- Computation of time window of energy supplier
            %The tpes variable represents the time interval where PEs exists
            %This parameter is analogous to the lifetime of the PEs
            
            %Number of time slots to ensure related to the PEs to ensure an AR=100%
            tpes = 0; %initialization of time interval related to PEs
            
            %Computation of the consumed energy, sum u�d for all services
            energyServices = zeros(n,1);
            for i = 1:n
                energyServices(i) = services(i,3) * services(i,5);
            end
            
            %Total energy consumed by the services
            totalEnergyServices = sum(energyServices,1);
            auxTpes = ceil(totalEnergyServices/PesValue); %auxiliar variable to compute tpes
            
            %Average duration of services
            averageTdServices = mean(services(:,5));
            
            %Computation of the module Sum{PdTd} mod Td
            modEnergyServTd = mod(auxTpes,averageTdServices);
            
            %Computation of mPEs
            if modEnergyServTd == 0
                tpes = auxTpes;
            else
                tpes = auxTpes + averageTdServices - modEnergyServTd;
            end
            %disp(tpes); %number of time slots of PEs, lifetime of PEs
            %tpes = 3; %value if the Pes is deterministic
            
            %--- Computation of time variable - tPd related with demand
            %This time interval value represents the time interval where Pd exist, i.e.,
            %where the demands exit.
            %This is only needed if we want to center the tpes value later on, around
            %services
            
            infoMinTinit = min(services(:,4));
            auxTinit_Td = services(:,4) + services(:,5);
            inforMaxTend = max(auxTinit_Td);
            
            tPd = inforMaxTend - infoMinTinit; %This is the time interval where are located the demands
            medianMPd = floor(tPd/2);
            tinitMedian = infoMinTinit + medianMPd;
            
            mediantpes = ceil(tpes/2); %mediantpes = ceil(tpes/2);
            auxtTinitPes = tinitMedian - mediantpes; %initial time of PEs centered to Pd
            
            if auxtTinitPes < 0
                auxtTinitPes = 0; %to ensure no negative values
            end
            
            %--------------------------------------------------------------------------
            %Power provided by energ supplier represented as a vector (constant value)
            %--------------------------------------------------------------------------
            
            auxPesVal = PesValue*ones(1,tpes); %lifetime of the services
            tinitPes = auxtTinitPes; %initial time of PEs
            totalTimePes = tinitPes + tpes; %total time of PEs
            auxPes = zeros(1,totalTimePes);
            auxPes(1,tinitPes+1:totalTimePes) = auxPesVal;
            
            %PEs = Pes*ones(1,tmax);
            Pes = auxPes; %power provided by the energy supplier
            %Pes = [0 0 3 3 3 0 0]; %Pes information if Pes is deterministic
            
            lenPes = length(Pes);
            auxTmax = zeros(1,tmax); %auxiliar variable to compare the value of m and PEs
            
            if lenPes < tmax
                Pes(numel(auxTmax)) = 0; %fill of zeros according to the analysis time window
            else
                tmax = lenPes; %in order to analyze within the maximum time window
            end
            
            %--- Time variable for graphs
            t = 0:1:(tmax-1); %variable time for graphs
            
            %--------------------------------------------------------------------------
            % Power stored in batteries
            %--------------------------------------------------------------------------
            
            %--- Power stored in batteries
            Pb = randi([1 2],1,length(tmax));
            PbSocMin = 0.2;%minimun level of state of charge of batteries, this level
            %power should be enough to fulfull the critical services
            PbSocMax = 0.8;%maximun charging level (soc - state of charge). In this point
            % it is needed to foster a battery discharging i.e. in this
            %case Pa = PEs + PBMax - PBsocMax
            PbMax = 1;
            PbMin = 0;
            
            %--- Total available power
            Pa = Pes + Pb;
            
            
            %--------------------------------------------------------------------------
            %Description of the input parameters of the system
            %--------------------------------------------------------------------------
            
%             disp('------ Information general parameters -------');
%             disp(['Number of services: ',num2str(n)]);
%             disp(['Maximum time horizon: ',num2str(tmax)]);
%             disp(['Valuer of power of the energy supplier: ',num2str(PesValue)]);
%             disp(['Power of the energy supplier as vector: ',num2str(Pes)]);
%             disp(' ');
            
%             disp('---------------------------------------------------------------------');
%             disp('Information of services:');
%             disp('Service(sk), Priority(lk), Power demanded(uk), Start time (tinitk), Life time (dk)');
%             disp('Forward time shifting (Ts_min), Ts_max (backward time shifting)');
%             disp(' ');
%             disp('TABLE I: Description of services');
%             disp('------------------- Demands ------------------');
%             disp('    sk    lk    uk   tinitk  dk  mts_min mts_max ');
            tableServices = services;
            tableServices(:,end-1) = tableServices(:,end-1) * -1;
            %disp(tableServices);
            tinitVarInfo = (services(:,4))';
            
            %------------------------------------------------------------------------------
            %Initial information and allocation of services without no shifting capablities
            %------------------------------------------------------------------------------
            
            %--- Initial information of services with no time shifting
            initServicesNoMTs = services;
            initServicesNoMTs(:,6:end) = 0;
            
            %[initNumVar,initIdVar,initVarInfo,initPriorVarInfo,initMtsVarInfo,...
            %     initPowVarServ] = funcInfoDemands(n,tmax,initServicesNoMTs);
            [initNumVar,initIdVar,initVarInfo,initPriorVarInfo,initMtsVarInfo,...
                initPowVarServ] = funcInfoDemands(n,tmax,initServicesNoMTs,Pes);
            
            
%             disp(' ');
%             disp('TABLE II: Initial information of services');
%             disp('---------------- Original services ---------------------');
%             disp('- Number - Sk - lk - mts - Power demanded per time slot)');
%             disp([initIdVar',initVarInfo',initPriorVarInfo',initMtsVarInfo',initPowVarServ]);
            
            %--- Combinations of original services
            [numRowInitCombVar,numColInitCombVar,infInitCombVar,initCombVar] = funcCombVarSer(initVarInfo);
            
%             disp(' ');
%             disp('------------------------------------------------------');
%             if length(unique(initVarInfo)) < n
%                 disp('There is no valid combination ');
%             else
%                 disp(['Number of combinations with original service (noMTs): ', num2str(numRowInitCombVar)]);
%             end
            
%             disp(' --------- Combinations of original services --------');
%             disp('- NumComb - Combination of original services --------');
%             disp([infInitCombVar',initCombVar]);
            
            %--- Consumed power of combination of the original services
            consumedPowerInitCombVar = sum(initPowVarServ,1);
            
%             disp(' ---------- Power consumed of original combination of services ------');
%             disp('- NumComb - Consumed Power per Time Slot ----------------------------');
%             disp([infInitCombVar',consumedPowerInitCombVar]);
            
            %--- Residual power of combination of the original services
            resPowInitCombVar = Pes - consumedPowerInitCombVar;
            
            disp('--- Residual power of original combination of services --------');
            disp('Residual power = PES - Consumed Power Combination of Variations');
            disp('- NumComb - Residual Power per Time Slot ----------------------');
            disp([infInitCombVar',resPowInitCombVar]);
            
            %--- AR, cost related and power demanded by the original combination of services
            %[arInitCombVar,costARInitCombVar,powInitCombVar] = funcARCostCombVarSer(numRowInitCombVar,...
            %    resPowInitCombVar,initCombVar,n,tmax,Pes,tpes,initPriorVarInfo,initPowVarServ,consumedPowerInitCombVar);
            [arInitCombVar,costARInitCombVar,powInitCombVar] = funcARCostCombVarSerRec(numRowInitCombVar,...
                resPowInitCombVar,initCombVar,n,tmax,Pes,tpes,initPriorVarInfo,initPowVarServ,consumedPowerInitCombVar);
            
            %--- Metrics of the initial/original distribution or allocation of services
            [normResPowCombVar,normPlackCombVar] = funcCompMetric(Pes,tpes,powInitCombVar,...
                arInitCombVar,tmax,resPowInitCombVar);
            
            disp(' ');
            disp(' --- Normalized values of the initial Combination of services ---');
            disp('- Comb. Var.  -  AR -  Norm. ResPow -  Norm. Plack');
            fprintf('     %s     %8.3f  %8.3f      %8.3f\n',num2str(initCombVar),...
                arInitCombVar,normResPowCombVar,normPlackCombVar);
            
            %--- Values for time shifting equal to zero
            if maxTs == 0 %no time shifting
                %--- Store of information parameters
                timeDurationInfo = [timeDurationInfo;iterTd]; %values of lifetime of services
                timeShiftingInfo = [timeShiftingInfo;iterTs]; %value of time shifting of services
                resPowCombVarInfo = [resPowCombVarInfo;normResPowCombVar]; %values of residual power of the best combinations
                arCombVarInfo = [arCombVarInfo;arInitCombVar]; %values of acceptance ratio of the best combinations
                lackPowCombVarInfo = [lackPowCombVarInfo;normPlackCombVar]; %values of missing power of the best combinations
                
                tElapsedCase = 0;
                runningTimeInfo = [runningTimeInfo;tElapsedCase]; %running time per each case (Mts and dk)
                
                numVar = n;
                numberVariationsInfo = [numberVariationsInfo;numVar]; %information about the number of variations
                
                iterCaseInfo = [iterCaseInfo;iterCase]; %values of lifetime of services
                continue;
            end
            
            
            %------------------------------------------------------------------------------
            %Initial assesment of the fitness function base of PEs and PD
            %------------------------------------------------------------------------------
            
            %--- Initial assessment of the residual energy according available power and
            %consumed power (energy)
            %This is a preliminar assesment and do not consider the time shifting
            %capability of services
            
            totAvailablePower = sum(Pes);
            totInitConsumedPower = sum(consumedPowerInitCombVar);
            totInitRemainderPower = totAvailablePower - totInitConsumedPower;
            
            
            %-------------------------------------------------------------------------------
            %Variations of service:
            %Application of time shifting strategy: Power demanded by variations of services
            %-------------------------------------------------------------------------------
            
            %--- Information about the services and specifically about the variations
            %of services considering the time shifitn interval
            %numVar: Number of services
            %idVar: Identification of variation within all variations
            %varInfo: Information of the service to which the variation belongs to
            %priorVarInfo: Priority information of variation
            %mtsVarInfo: Maximum time shifting of variation
            %powVarServ: Power demanded per variation and per time slot
            
%             [numVar,idVar,varInfo,priorVarInfo,mtsVarInfo,...
%                 powVarServ] = funcInfoDemands(n,tmax,services);
            [numVar,idVar,varInfo,priorVarInfo,mtsVarInfo,...
                powVarServ] = funcInfoDemands(n,tmax,services,Pes);
            
            disp(' ');
            disp('-----------------------------------------------');
            %disp('-- Valid combinations per service and valid combinations among services --');
            disp(['Number of valid variations of services: ', num2str(numVar)]);
            disp(' ');
            disp('TABLE IV: Valid Variations per Service');
            disp('---------------- Variations per service ---------------------');
            disp('- Number - Sk - lk - mts - Power demanded per time slot)');
            disp([idVar', varInfo', priorVarInfo', mtsVarInfo', powVarServ]);
            
            
            %**************************************************************************
            %--------------------------------------------------------------------------
            %Greedy Algorithm
            %--------------------------------------------------------------------------
            %**************************************************************************
    
            [costLkBestCombVar,costMkBestCombVar,costARBestCombVar,totCostBestComVar,...
                powDemandServInfo,normResPowCombVar,arCombVar,normPlackCombVar,...
                processServ,proccessedVarServ] = funcGreedyDRAlloc(Pes,...
                tpes,n,initVarInfo,tinitVarInfo,initPriorVarInfo,...
                initPowVarServ,varInfo,priorVarInfo,mtsVarInfo,powVarServ);

            
            disp(' ');
            disp(' ------------------------------------------------------   Final information   --------------------------------------------------');
            disp(' ');
            disp(' ---------------------------------   Information of the best Combination of variations of services -----------------------------');
            disp('- NumComb -  Comb. Var.  -  costLk  - costMk  - CostAR  - totCost -   AR -    Power demanded   - Residual power -  Missing power');
            fprintf('%10d    %s %10d %10d   %8.3f  %8.3f  %8.3f     %s \t %s \t   %s\n',...
                num2str(1),num2str(processServ),costLkBestCombVar,costMkBestCombVar,...
                costARBestCombVar,totCostBestComVar,arCombVar,num2str(powDemandServInfo),...
                num2str(normResPowCombVar),num2str(normPlackCombVar));
            
            tElapsedCase = toc(tStartCase); %final time to per case
            
            %--------------------------------------------------------------------------
            % Graphs of energy supplier and the combination of variations of services
            %--------------------------------------------------------------------------
            
            %Power allocation for selected demand
            hold on;
            grid on;
            title('Power Demanded by Services');
            xlabel('Time slot');
            ylabel('Power units');
            tg = t + 0.5;
            bar(tg,Pes,1,'c');
            bar(tg,powDemandServInfo,1);
            grid on;
            legend('Pes','Pdemanded');
            idGraph = strcat('Td',num2str(iterTd),'_Ts',num2str(iterTs));
            saveas(gcf,idGraph,'epsc')
                        
            %--- Information of each case
            idCase = strcat('Td',num2str(iterTd),'_Ts',num2str(iterTs));
            parsave(idCase,iterTd,iterTs,normResPowCombVar,arCombVar,normPlackCombVar);
            
            %--- Store of information parameters
            timeDurationInfo = [timeDurationInfo;iterTd]; %values of lifetime of services
            timeShiftingInfo = [timeShiftingInfo;iterTs]; %value of time shifting of services
            resPowCombVarInfo = [resPowCombVarInfo;normResPowCombVar]; %values of residual power of the best combinations
            arCombVarInfo = [arCombVarInfo;arCombVar]; %values of acceptance ratio of the best combinations
            lackPowCombVarInfo = [lackPowCombVarInfo;normPlackCombVar]; %values of missing power of the best combinations
            
            runningTimeInfo = [runningTimeInfo;tElapsedCase]; %running time per each case (Mts and dk)
            
            numberVariationsInfo = [numberVariationsInfo;numVar]; %information about the number of variations
            
            iterCaseInfo = [iterCaseInfo;iterCase]; %values of lifetime of services
            
        end %iterations for Ts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    end %iterations for Td %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end %iterations for IterCase %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

totalRunningTime = toc;

% ---- Saving variables for getting the pictorial results
parGreedySolCaseB = [iterCaseInfo,timeDurationInfo,timeShiftingInfo,resPowCombVarInfo,...
    arCombVarInfo,lackPowCombVarInfo,runningTimeInfo,numberVariationsInfo];
save('parGreedySolCaseB.mat','parGreedySolCaseB','iterCaseInfo','timeDurationInfo',...
    'timeShiftingInfo','resPowCombVarInfo','arCombVarInfo','lackPowCombVarInfo',...
    'runningTimeInfo','totalRunningTime','numberVariationsInfo');





%**************************************************************************
%--------------------------------------------------------------------------
% Functions
%--------------------------------------------------------------------------
%**************************************************************************

%--------------------------------------------------------------------------
%------ Function for computing the power demanded and all information of
%variation per services considering the time shifting interval
%--- Input parameters:
%inN: Number of services
%inTmax: Maximum time horizon
%inServices: Information of services
%inPes: Information of available Pes
%--- Out parameters:
%- outNumVariat: Total number of valid variations
%- outInfIdVariat: Identification of all possible variation per services (row
%vector)
%- outServInfo: Information of the service accoring to its variation. Each
%service can be originated one or more than one variations.
%- outPriorityInfo: Information about the priority level of a variation of
%service.
%outMtsInfo: Information about the maximum time shifting of a variation of
%service.
%outPowerVar: Power demanded per variation and per time slot
%Example: [numVar,idVar,varInfo,priorVarInfo,mtsVarInfo,powVarServ] = funcInfoDemands(n,tmax,services);

function [outNumVariat,outInfIdVariat,outServInfo,...
    outPriorityInfo,outMtsInfo,outPowerVar] = funcInfoDemands(inN,inTmax,inServices,inPes)


%Power demanded for services
powerDemanded = zeros(inN,inTmax);
backwardDemand = zeros(1,inTmax);
forwardDemand = zeros(1,inTmax);
cont = 0; % variable to know the number of possible combinations

demandPower = []; %variable array for the information of all demands (services)
serviceInfo = []; %information of the processed services
outMtsInfo = []; %number of shifting per service in terms of time slots
outPriorityInfo = []; %information of the priority of each service
auxTShif = 0;
auxPres = 0; %auxiliar variable to asses if Pres is negative, in this case
%the variation is considered as a not valid variation

%auxiliar variables for time shifting
auxBackshifted = zeros(inN,inTmax);
auxForshifted = zeros(inN,inTmax);

for i = 1:inN % i number of services
    
    if (inServices(i,4) + inServices(i,5)) > inTmax %demands out of range
        
        disp('Not valid variation');
        %         powerDemanded(i,:)= Inf;
        %         cont = cont + 1;
        %         serviceInfo = [serviceInfo,i];
        %         demandPower =[demandPower; powerDemanded(i,:)];
        %         auxTShif = 0; %indicates no time shifting(numer slots)
        %         outMtsInfo = [outMtsInfo,auxTShif];
        %         outPriorityInfo = [outPriorityInfo,inServices(i,2)];
        %
        %         auxInvalidDemand = []; %variable to save the power demand
        %         tinit = 1 + inServices(i,4);
        %         td = inServices(i,5) - 1;
        %         auxInvalidDemand(tinit : tinit + td) = 1 * inServices(i,3);
        %
        %         if inServices(i,7) > 0 %if there exist time shifting backward
        %
        %             for j = 1 : inServices(i,7)
        %
        %                 %Backward time shifting
        %                 if ((inServices(i,4) + inServices(i,5) + j) > inTmax)
        %                     powerDemanded(i,:)= Inf;
        %                     %disp('No valid demand, demand out of limit');
        %                     %disp(' ');
        %                     demandPower =[demandPower; powerDemanded(i,:)];
        %                 else
        %                     backwardDemand(:,j+1:end) = auxBackshifted(:,1:end-j);
        %                     %disp(['Demand ',num2str(i), ' backward time shifting ', num2str(j), ' time slots']);
        %                     %disp(backwardDemand);
        %                     demandPower =[demandPower; backwardDemand];
        %                 end
        %                 backwardDemand = zeros(1,inTmax); %n for erase de previous result
        %
        %                 cont = cont + 1;
        %                 serviceInfo = [serviceInfo,i];
        %                 outMtsInfo = [outMtsInfo,j];
        %                 outPriorityInfo = [outPriorityInfo,inServices(i,2)];
        %
        %             end
        %         end
        %
        %
        %         if inServices(i,6) > 0 %if there exist time shifting
        %
        %             for j = 1: inServices(i,6)
        %                 %Forward time shifting
        %                 if ((inServices(i,4) - j) < 0)
        %                     powerDemanded(i,:)= Inf;
        %                     demandPower =[demandPower; powerDemanded(i,:)];
        %
        %                 else
        %
        %                     [rauxInvDem,cauxInvDem] = size(auxInvalidDemand);
        %                     forwardInvDemand = zeros(1,cauxInvDem);
        %                     forwardInvDemand(:,1:end-j) = auxInvalidDemand(:,j+1:end);
        %                     valInvDemand = forwardInvDemand(:,1:inTmax);
        %
        %                     if (length(find(valInvDemand > 0)) < inServices(i,5))
        %                         powerDemanded(i,:)= Inf;
        %                         demandPower =[demandPower; powerDemanded(i,:)];
        %                     else
        %                         demandPower =[demandPower; valInvDemand];
        %                     end
        %
        %                 end
        %
        %                 cont = cont + 1;
        %                 serviceInfo = [serviceInfo,i];
        %                 outMtsInfo = [outMtsInfo,j];
        %                 outPriorityInfo = [outPriorityInfo,inServices(i,2)];
        %
        %             end
        %         end
        
    else  %demands within the range
        tinit = 1 + inServices(i,4);
        td = inServices(i,5) - 1;
        powerDemanded(i,tinit : tinit + td) = 1 * inServices(i,3);
        
        auxPres = inPes - powerDemanded(i,:); %assessment of Pres of variation
        
        if length(find(auxPres<0)) > 0
            %disp('This is a invalidad variation because it produces negative Pres');
        else
            %disp('This is a valid variation');
            cont = cont + 1;
            serviceInfo = [serviceInfo,i];
            demandPower =[demandPower; powerDemanded(i,:)];
            auxTShif = 0; %indicates no time shifting(numer slots)
            outMtsInfo = [outMtsInfo,auxTShif];
            outPriorityInfo = [outPriorityInfo,inServices(i,2)];
            %disp(['Demand ',num2str(i), ' without time shifting']);
            %disp(powerDemanded(i,:));
        end
        
        
        %auxBackshifted = zeros(n,m);
        auxBackshifted = powerDemanded(i,:);
        %auxForshifted = zeros(n,m);
        auxForshifted = powerDemanded(i,:);
        
        if inServices(i,7) > 0 %if there exist time shifting
            
            for j = 1 : inServices(i,7)
                
                %Backward time shifting
                if ((inServices(i,4) + inServices(i,5) + j) > inTmax)
                    %disp('It is a not variation');
                    %powerDemanded(i,:)= Inf;
                    %disp('No valid demand, demand out of limit');
                    %disp(' ');
                    %demandPower =[demandPower; powerDemanded(i,:)];
                else
                    backwardDemand(:,j+1:end) = auxBackshifted(:,1:end-j);
                    %disp(['Demand ',num2str(i), ' backward time shifting ', num2str(j), ' time slots']);
                    %disp(backwardDemand);
                    
                    auxPres = inPes - backwardDemand; %assessment of Pres of variation
                    
                    if length(find(auxPres<0)) > 0
                        %disp('This is a invalidad variation because it produces negative Pres');
                    else
                        %disp('This is a valid variation');
                        demandPower =[demandPower; backwardDemand];
                        cont = cont + 1;
                        serviceInfo = [serviceInfo,i];
                        outMtsInfo = [outMtsInfo,j];
                        outPriorityInfo = [outPriorityInfo,inServices(i,2)];
                        
                        %disp(['Demand ',num2str(i), ' without time shifting']);
                        %disp(powerDemanded(i,:));
                    end
                    
                end
                backwardDemand = zeros(1,inTmax); %n for erase de previous result
                
            end
        end
        
        if inServices(i,6) > 0 %if there exist time shifting
            
            for j = 1: inServices(i,6)
                %Forward time shifting
                if ((inServices(i,4) - j) < 0)
                    %disp('It is a not variation');
                    %powerDemanded(i,:)= Inf;
                    %demandPower =[demandPower; powerDemanded(i,:)];
                    
                else
                    %disp('This is a valid variation');
                    forwardDemand(:,1:end-j) = auxForshifted(:,j+1:end);
                    %disp(['Demand ',num2str(i), ' forward time shifting ', num2str(j), ' time slots']);
                    %disp(forwardDemand);
                    
                    auxPres = inPes - forwardDemand; %assessment of Pres of variation
                    
                    if length(find(auxPres<0)) > 0
                        %disp('This is a invalidad variation because it produces negative Pres');
                    else
                        %disp('This is a valid variation');
                        demandPower =[demandPower; forwardDemand];
                        cont = cont + 1;
                        serviceInfo = [serviceInfo,i];
                        outMtsInfo = [outMtsInfo,j];
                        outPriorityInfo = [outPriorityInfo,inServices(i,2)];
                        %disp(['Demand ',num2str(i), ' without time shifting']);
                        %disp(powerDemanded(i,:));
                    end
                    
                end
                forwardDemand = zeros(1,inTmax); %n for erase de previous result
                
            end
            
        end
        
    end
    
end

%disp('--------------------------------------------------------------------------------');
%disp('-- Possible variations per service and possible combinations among services --');
%disp(' ');
%disp(['Number of possible combinations per service: ', num2str(cont)]);
%disp(' ');
%disp('Order of service combinations: without Ts, Ts backward, Ts forward');

%For the first evaluation of the algorithm and if no variations ar
%possitive
if cont == 0
    
    for i = 1:inN
        tinit = 1 + inServices(i,4);
        td = inServices(i,5) - 1;
        powerDemanded(i,tinit : tinit + td) = 1 * inServices(i,3);
        demandPower =[demandPower; powerDemanded(i,:)];
        serviceInfo = [serviceInfo,i];
        outMtsInfo = [outMtsInfo,0];
        outPriorityInfo = [outPriorityInfo,inServices(i,2)];
   end
    
end

infoDemands = demandPower; %only to show the results of demand demandPower
infoDemands(infoDemands == Inf) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%disp('TABLE II: Possible Combinations per service');
%disp(' ------------- Possible Combinations per service ------------------');
%disp(' "---" means not valid demand, invalid time shifting');
%disp('In this table in column 3 the time slot used is given in terms of power consumed by demand');
%disp('- Number - Sk - TimeSlot used - Absolute Time shifting Performed');
%numberServices = 1:cont;
%[rInfoD,cInfoD] = size(infoDemands);
%disp([numberValidServices', serviceInfo', demandPower]);
%disp('- Number - Sk - Type of demand (in terms of power consumed by demand)');
%disp([numberServices', serviceInfo', infoDemands]);

% for i = 1:cont
%     if infoDemands(i,:) == 0
%         disp(['     ',num2str(numberServices(i)), '     ',...
%             num2str(serviceInfo(i)) 9, '  ', '-------' blanks(10),...
%             '-']); %num2str(shiftingServ(i))
%     else
%         disp(['     ',num2str(numberServices(i)), '     ',...
%             num2str(serviceInfo(i)) 9, '  ',num2str(infoDemands(i,:)) blanks(10), ...
%             num2str(shiftingServ(i))]);
%
%     end
% end
% disp(' ');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--- Valid demands avoiding the invalid type of demands (time shifting)

%--- Valid type of demands
infoDemandsTrans = infoDemands';
outPowerVar = infoDemands(find(sum(infoDemandsTrans)>0),:);
[outNumVariat, valdc] = size(outPowerVar);
orderValidDemands = find(sum(infoDemandsTrans)>0);
noValidDemands = find(sum(infoDemandsTrans)==0);
[noValr, noValc] = size(noValidDemands);

outServInfo = serviceInfo(find(sum(infoDemandsTrans)>0));

outPriorityInfo = outPriorityInfo(find(sum(infoDemandsTrans)>0));

%--- Power demanded
demandPower = demandPower(find(sum(infoDemandsTrans)>0),:);

%--- Time shifting information
outMtsInfo = outMtsInfo(find(sum(infoDemandsTrans)>0));

%disp(' ');
%disp('--------------------------------------------------------------------------');
%disp('-- Valid combinations per service and valid combinations among services --');
%disp(' ');
%disp(['Number of valid combinations per service: ', num2str(outNumVariat)]);
%disp(' ');
%disp('TABLE III: Valid Combination per Service');
%disp('---------------- Valid combination per service ---------------------');
%disp('- Number - Sk - lk - mts - Power demanded per time slot)');
outInfIdVariat = 1:outNumVariat;
%disp([numberValidServices', serviceInfo', demandPower]);
%disp([orderValidDemands', valserviceInfo', valinfoDemads]);
%disp([outInfIdVariat', outServInfo', outPriorityInfo', outMtsInfo', outPowerVar]);


%Type of demands according to the time slot where the service is processed
%This information is needed later on, in the computation of power
%inforDemPerSlot = infoDemands;
inforDemPerSlot = outPowerVar;
for i = 1:outNumVariat
    for j = 1:valdc
        if (inforDemPerSlot(i,j) > 0)
            inforDemPerSlot(i,j) = j;
        end
    end
end
%inforDemPerSlot
%disp(' ');
%disp('Types of demands according to the time slot where the service is processed');
%disp('- Number - Sk - Type of demand -----');
%disp([numberServices', serviceInfo', inforDemPerSlot]);


%Type of demands according to the service to which they belong
%inforDemPerSer = infoDemands;
inforDemPerSer = outPowerVar;
inforDemPerSer(inforDemPerSer>0) = 1; %to produce a matrix with unity elements
[rdps cdps] = size(inforDemPerSer);

for i = 1:rdps
    %inforDemPerSer(i,:) = inforDemPerSer(i,:)* serviceInfo(:,i);
    inforDemPerSer(i,:) = inforDemPerSer(i,:)* outServInfo(:,i);
end
%disp(' ');
%disp('Types of demands according to the service to which they belong');
%disp('- Number - Sk - Type of demand -----');
%disp([numberServices', serviceInfo', inforDemPerSer]);

end


%--------------------------------------------------------------------------
%------ Function for computing the combinations among variations of
%services
%--- Input parameters:
%inVarInfo: Information of all variations per service, ID of each variation
%--- Out parameters:
%outNumRowCombVar: Number of combinations of variations of services
%outNumColCombVar: Number of processed services at the same time (n)
%outInfCombVar: Identification of combination
%outCombVar: Information of combinations of variations per services
%Example: [numRowCombVar,numColCombVar,infCombVar,combVar] =
%funcCombVarSer(varInfo;

function [outNumRowCombVar,outNumColCombVar,outInfCombVar,outCombVar] = funcCombVarSer(inVarInfo)

%Values of services
valServ = unique(inVarInfo);
[rvalSer,cvalSer] = size(valServ);

%Temporal information of service indexes
tmpInfIndSer = {};

for i = 1:cvalSer
    auxPosServ = find(inVarInfo == i);
    tmpInfIndSer{end+1} = auxPosServ; %to append the indexes of all services
end

numSer = cellfun(@numel,tmpInfIndSer); %number of demands per service
cumSumSer = cumsum(numSer); %cummulative sum of number of services
combSerPos = fullfact(numSer); % different combinations of elements among services
%Expansion function to obtain combinations
outCombVar = bsxfun(@plus,combSerPos,[0, cumSumSer(1:end-1)]);
[outNumRowCombVar,outNumColCombVar] = size(outCombVar);
outInfCombVar = 1:outNumRowCombVar; %information id combination according variations

end


%--------------------------------------------------------------------------
%------ Function for computing the acceptance ratio and the cost related
%per combination of variations of services considering priority
%--- Input parameters:
%inNumRowCombVar: Number of variations of services
%inResPowCombVar: Residual information of combination of variations
%inCombVar: Information of Combination of variations
%inN: Number of variations per combination
%inTmax: Maximum time horizon
%inPes: Information of Pes
%inTpes: Time window related to Pes
%inPriorVarInfo: Priority of variations of service
%inPowVarServ: Power of variations of service
%inConsumedPowerComb: Consumed power per combination
%--- Out parameters:
%arCombVar: Acceptance ratio combination of variations of services
%outCostCombVar: Cost related to rejected service (acceptance ratio)
%outPowCombVar: Power consumed by only the processed services
%Example: [arCombVar,costCombVar,powCombVar] = funcARCostCombVarSer(numRowCombVar,resPowCombVar,combVar,n,tmax,Pes,tpes,priorVarInfo,powVarServ,consumedPowerComb);

function [outARCombVar,outCostCombVar,outPowCombVar] = funcARCostCombVarSer(inNumRowCombVar,...
    inResPowCombVar,inCombVar,inN,inTmax,inPes,inTpes,inPriorVarInfo,...
    inPowVarServ,inConsumedPowerComb)

outARCombVar = zeros(inNumRowCombVar,1); %Acceptance ration of combinations of variations
outCostCombVar = zeros(inNumRowCombVar,1); %Cost of combinations of variations
outPowCombVar = zeros(inNumRowCombVar,inTmax); %Power of combinations of variations

for i = 1:inNumRowCombVar %exploration of all combinations
    
    %----------------------------------------------------------------------
    %--- Combinations of variations with negative residual power
    %The cost of each service that cannot be processed will be 1000(big M)
    if (find(inResPowCombVar(i,:)<0) > 0)
        %disp('Negative combination of variations of services');
        %outARCombVar(i,1) = 0;
        %outCostCombVar(i,1) = inN*1000;
        
        %--- Services that compose the negative combination of variations
        auxNegServCombVar = inCombVar(i,:);
        
        %--- Priority info of the services that compose the negative
        %combination of variations
        auxPriorNegSerCombVar = inPriorVarInfo(1,auxNegServCombVar);
        
        
        %------------------------------------------------------------------
        %--- Processing of negative combination of variatiosn with equal
        %priorities in services
        if length(unique(auxPriorNegSerCombVar)) == 1
            %disp('Negative combination of variations of services with equal priorities');
            
            %Combination of possible rejectetable services
            allRejSerCombVar = [];
            
            %Maximun number of colums among combinations
            auxLarRejServComVar = zeros(1,inN);
            
            %--- Analysis of all possible rejectable services
            for j=1:inN
                combRejSer = combnk(1:inN,j); %all combinations of possible rejected services
                [rCombRejSer,cCombRejSer] = size(combRejSer);
                
                if cCombRejSer < inN
                    combRejSer(:,numel(auxLarRejServComVar)) = 0;
                end
                
                %All possible combinations of rejectable services
                allRejSerCombVar = [allRejSerCombVar; combRejSer];
            end
            %disp(allRejSerCombVar);
            [rAllRejSerCombVar,cAllRejSerCombVar] = size(allRejSerCombVar);
            
            %--- Analysis of power demanded by the non-rejectable services
            %and the cost related to the rejection of the services
            
            %After the computation of the residual power with the information of
            %non-rejectable services if the resulting Pres is negative cost of 10000
            %Cost of Pres non negative cero
            %Therefore the cost of ar is equal to CostAR= costNegPres + cost for each service rejected
            %Example: CostAR = 10000 + 2*1000 (2 services rejected)
            %If after the rejection, and fater the computation of the power consumed by
            %the non-rejectable services the Pres is positive the cost related is the
            %the Pres normalized
            
            tempCostRejServ = zeros(rAllRejSerCombVar,1); %temporal information about the cost if a service is rejected
            tempCostResPow = zeros(rAllRejSerCombVar,1); %temporal information about the cost if the residual power after
            %the assigned cost will be a
            %big value (1000), if the
            %residual power is positive
            %this value can be se a metric
            %(shigma Pres)
            tempAcceptanceRatio = zeros(rAllRejSerCombVar,1); %temporal information of acceptance ratio
            tempPowerDemandNonRejSev = zeros(rAllRejSerCombVar, inTmax); %temporal information of power consumed
            %by non-rejectable
            %services
            
            for j = 1:rAllRejSerCombVar
                
                %Information about the number of rejected services
                numRejServ = length(find(allRejSerCombVar(j,:) > 0));
                
                %--- Cost of rejection of all possible rejectable services
                tempCostRejServ(j,1) = numRejServ * 1000;
                
                %--- Computation of power of nonrejectable services
                %Variable to save all possible services of combination
                varAuxRejecServ = auxNegServCombVar;
                
                %Variable to be deleted according the combination of rejected services
                tempAuxRejecServ = varAuxRejecServ;
                
                %Variable to store the temporal information of rejectable services
                tempRejServ = allRejSerCombVar(j,:);
                tempRejServ(tempRejServ == 0) = []; %delete the columns with zeros
                
                %Information of non-rejectable services per combination of variations
                tempAuxRejecServ(:,tempRejServ) = [];
                
                %Power consumed by non-rejectable services
                powNonRejServ = sum(inPowVarServ(tempAuxRejecServ,:),1);
                
                %Residual power of non rejectable services
                resPowNonRejSer = inPes - powNonRejServ;
                
                if (find(resPowNonRejSer<0) > 0)
                    %disp('The combination of non-rejectable services produce a negative residual power');
                    %--- Cost related to the negative residual power of all
                    %combinations
                    tempCostResPow(j,1) = 10000; %cost asigned if the combination of non-rejectable services
                    %still produce a negative residual
                    %power
                    tempAcceptanceRatio(j,1) = 0; %if Pres still negative no processing of demands
                    tempPowerDemandNonRejSev(j,:) = 0; %no real consumption
                else
                    %disp('The combination of non-rejectable services produce a positive residual power');
                    %--- Cost related to the negative residual power of all
                    %combinations
                    auxSigResRejServ = ((sum(resPowNonRejSer.^2))/inTpes)^(1/2); %metric for resiudal power of rejected services
                    tempCostResPow(j,1) = auxSigResRejServ; %cost related to the remaining Pres
                    tempAcceptanceRatio(j,1) = ((inN - numRejServ)/inN)*100; %computation of AR
                    tempPowerDemandNonRejSev(j,:) = powNonRejServ; %power consumed according the services processed
                end
            end
            
            %--- Total cost related to rejection per Combination of Variations of
            %services
            tempTotalCostRejServ = tempCostRejServ + tempCostResPow; %temporal total cost related to rejection
            %tempTotalCostRejServ =
            %tempCostRejServ + tempCostResPow
            
            %Sorted information of all analysis of non-rejectable services
            [tempCostRej,indTempCosRej] = sort(tempTotalCostRejServ); %The best value is the first in the list
            
            %Information of AR for services of equal priority
            infARNonRejSer = tempAcceptanceRatio(indTempCosRej(1,1),1);
            outARCombVar(i,1) = infARNonRejSer;
            
            %Information of cost for services of equal priority
            infCosNonRejSer = tempTotalCostRejServ(indTempCosRej(1,1),1);
            outCostCombVar(i,1) = infCosNonRejSer;
            
            %Information of power consumed for services of equal priority
            infConsumPowNonRejSer = tempPowerDemandNonRejSev(indTempCosRej(1,1),:);
            outPowCombVar(i,:) = infConsumPowNonRejSer;
            
            
            %------------------------------------------------------------------
            %--- Processing of negative combination of variations with
            %different priorities in services
        else
            %disp('Negative combination of variations of services with different priorities');
            %More cost discarding a service with higher priority level
            
            availablePowServ = inPes; %variable to store the information of the available power
            
            %Sort service priorities from the highest (1) to the lowest (n)
            [sortAuxPrior,indSortAuxPrior] = sort(auxPriorNegSerCombVar);
            %Services of the combination of variations sorted according
            %priorities in descending order of priority
            sortAuxreject = auxNegServCombVar(1,indSortAuxPrior);
            
            %--- Processing of critical services (lk = 1)
            %It is assumed that the system always must provide energy for
            %critical services
            
            %Information of critical services within the Combination of
            %Variations
            criticalServ = [];
            criticalServ = sortAuxreject(1,find(sortAuxPrior==1));
            
            %Power of each critical services
            auxPowCriticalServ = inPowVarServ(criticalServ,:);
            
            %Power consumed by critical services
            powCS = sum(auxPowCriticalServ,1); %power demanded by critical services
            remainPower = availablePowServ - powCS; %power demanded by non-critical services
            powNCS = remainPower; %available power for non critical services
            
            if find(remainPower < 0) %no power for CS, which is a constraint in the system
                disp('No power enough for critical services');
                disp('Ensure power for critical services or use batteries');
                %break; %No continue processing
                %rejectServ = rCS;
                
                %Computation of AR metric, the related cost and the power
                %demanded.
                %This criteria coul be improved by analyzing from the CS
                %the service(s) whose rejection produce a minimum Pres.
                outARCombVar(i,1) = 0; %Information of Acceptance Ratio
                outCostCombVar(i,1) = inN*1000; %Information of cost related to acceptance ratio
                outPowCombVar(i,:) = 0; % No power consumed per combination because not meet CS
                
            else
                %The available power is sufficient to at least meet CS, the
                %remaining power will be used for NCS
                
                
                %--- Processing of non-critical services (lk != 1)
                
                %Information of non-critical services within the combination of
                %variations
                nonCriticalServ = [];
                nonCriticalServ = sortAuxreject(1,find(sortAuxPrior~=1));
                numNonCS = length(nonCriticalServ); %number of NCS
                
                %Available power for non-critical services
                powNCS(powNCS<0)=0; %to ensure only possitive values
                availablePowNCS = powNCS;
                
                if availablePowNCS(availablePowNCS > 0)
                    %disp('There exist power for NCS');
                    
                    %Sorting of NCS according descending order of priorities
                    sortAuxPriorNCS = sortAuxPrior(sortAuxPrior > 1);
                    
                    %Possible values of priority for NCS
                    valuesPrior = sort(unique(sortAuxPriorNCS));
                    
                    
                    %--- Analysis of possible rejectable services according
                    %the descending order of priority
                    
                    availablePowNCSPri = availablePowNCS; %variable to store the information of the available power for NCS in
                    %in the analysis
                    %of priority
                    
                    countRejServPri = 0; %counter of NCS rejected services in the priority analysis
                    auxPowComNonRejServPri = zeros(1,length(availablePowNCSPri)); %variable to store the consumed power according the increase in priority
                    totPowComNonRejSerPri = zeros(1,length(availablePowNCSPri)); %variable to store the consumed power
                    auxPresComNonRejServPri = zeros(1,length(availablePowNCSPri)); %variable to store the residual power according the increase in priority
                    
                    
                    for j = 1:length(valuesPrior)
                        
                        %Information of non-critical services within the combination of
                        %variations according to priority which they belong
                        %to
                        nonCriServPri = [];
                        nonCriServPri = nonCriticalServ(1,find(sortAuxPriorNCS==valuesPrior(j)));
                        numNonCSPri = length(nonCriServPri); %number of NCS per priority
                        
                        %Power of each non-critical service according priority
                        auxPowNonCriServPrio = inPowVarServ(nonCriServPri,:);
                        
                        %Power consumed by non-critical services per
                        %priority
                        powNCSPri = sum(auxPowNonCriServPrio,1); %power demanded by critical services
                        remainPowerNCSPri = availablePowNCSPri - powNCSPri; %power demanded by non-critical services
                        
                        
                        if find(remainPowerNCSPri(1,:) < 0)
                            %disp('At least a service must be rejected within this priority');
                            
                            
                            if length(find(availablePowNCSPri==0)) == length(availablePowNCSPri)
                                %disp('There no exist power in the system');
                                
                                countRejServPri = countRejServPri + numNonCSPri; %add NCS rejected service to all rejected services
                                auxPowComNonRejServPri = zeros(1,length(availablePowNCSPri));
                                auxPresConNonRejServPri = availablePowNCSPri - auxPowComNonRejServPri;
                                availablePowNCSPri = auxPresConNonRejServPri;
                                
                                totPowComNonRejSerPri = totPowComNonRejSerPri + auxPowComNonRejServPri; %cummulative consumed power
                                continue;
                                
                            end
                            
                            
                            if numNonCSPri == 1 %If only one service the power is not sufficient
                                %and this sevice should be rejected
                                
                                countRejServPri = countRejServPri + 1; %add 1 rejected service to all rejected services
                                auxPowComNonRejServPri = zeros(1,length(availablePowNCSPri));
                                auxPresConNonRejServPri = availablePowNCSPri - auxPowComNonRejServPri;
                                availablePowNCSPri = auxPresConNonRejServPri;
                                
                                totPowComNonRejSerPri = totPowComNonRejSerPri + auxPowComNonRejServPri; %cummulative consumed power
                                
                            else
                                
                                %Combinatorial analysis of rejectable service
                                %for priority valuesPrior(j)
                                
                                %Combination of possible rejectetable services
                                allRejSerCombVarPri = [];
                                
                                %Maximun number of colums among combinations
                                auxLarRejServComVarPri = zeros(1,numNonCSPri);
                                
                                %--- Analysis of all possible rejectable services
                                for k=1:numNonCSPri
                                    combRejSerPri = combnk(1:numNonCSPri,k); %all combinations of possible rejected services
                                    [rCombRejSerPri,cCombRejSerPri] = size(combRejSerPri);
                                    
                                    if cCombRejSerPri < numNonCSPri
                                        combRejSerPri(:,numel(auxLarRejServComVarPri)) = 0;
                                    end
                                    
                                    %All possible combinations of rejectable services
                                    allRejSerCombVarPri = [allRejSerCombVarPri; combRejSerPri];
                                end
                                %disp(allRejSerCombVar);
                                [rAllRejSerCombVarPri,cAllRejSerCombVarPri] = size(allRejSerCombVarPri);
                                
                                
                                %--- Analysis of power demanded by the non-rejectable services
                                %and the cost related to the rejection of
                                %the services per priority
                                
                                %After the computation of the residual power with the information of
                                %non-rejectable services if the resulting Pres is negative cost of 10000
                                %Cost of Pres non negative cero
                                %Therefore the cost of ar is equal to CostAR= costNegPres + cost for each service rejected
                                %Example: CostAR = 10000 + 2*1000 (2 services rejected)
                                %If after the rejection, and after the computation of the power consumed by
                                %the non-rejectable services the Pres is positive the cost related is the
                                %the Pres normalized
                                
                                tempCostRejServPri = zeros(rAllRejSerCombVarPri,1); %temporal information about the cost if a service is rejected
                                tempCostResPowPri = zeros(rAllRejSerCombVarPri,1); %temporal information about the cost if the residual power after
                                %the assigned cost will be a
                                %big value (1000), if the
                                %residual power is positive
                                %this value can be se a metric
                                %(shigma Pres)
                                tempAccepRatioPri = zeros(rAllRejSerCombVarPri,1); %temporal information of acceptance ratio
                                tempPowerDemandNonRejSevPri = zeros(rAllRejSerCombVarPri, inTmax); %temporal information of power consumed
                                %by non-rejectable
                                %services
                                
                                
                                for k = 1:rAllRejSerCombVarPri
                                    
                                    %Information about the number of rejected services
                                    numRejServPri = length(find(allRejSerCombVarPri(k,:) > 0));
                                    
                                    %--- Cost of rejection of all possible rejectable services
                                    tempCostRejServPri(k,1) = numRejServPri * 1000;
                                    
                                    
                                    %--- Computation of power of nonrejectable services
                                    %Variable to save all possible services of combination
                                    varAuxRejecServPri = nonCriServPri;
                                    
                                    %Variable to be deleted according the combination of rejected services
                                    tempAuxRejecServPri = varAuxRejecServPri;
                                    
                                    %Variable to store the temporal information of rejectable services
                                    tempRejServPri = allRejSerCombVarPri(k,:);
                                    tempRejServPri(tempRejServPri == 0) = []; %delete the columns with zeros
                                    
                                    %Information of non-rejectable services per combination of variations
                                    tempAuxRejecServPri(:,tempRejServPri) = [];
                                    
                                    %Power consumed by non-rejectable services
                                    powNonRejServPri = sum(inPowVarServ(tempAuxRejecServPri,:),1);
                                    
                                    
                                    %Residual power of non rejectable services
                                    resPowNonRejSerPri = availablePowNCSPri - powNonRejServPri;
                                    
                                    if (find(resPowNonRejSerPri<0) > 0)
                                        %disp('The combination of non-rejectable services produce a negative residual power');
                                        %--- Cost related to the negative residual power of all
                                        %combinations
                                        tempCostResPowPri(k,1) = 10000; %cost asigned if the combination of non-rejectable services
                                        %still produce a negative residual
                                        %power
                                        tempAccepRatioPri(k,1) = 0; %if Pres still negative no processing of demands
                                        tempPowerDemandNonRejSevPri(k,:) = 0; %no real consumption
                                    else
                                        %disp('The combination of non-rejectable services produce a positive residual power');
                                        %--- Cost related to the negative residual power of all
                                        %combinations
                                        auxSigResRejServ = ((sum(resPowNonRejSerPri.^2))/inTpes)^(1/2); %metric for resiudal power of rejected services
                                        tempCostResPowPri(k,1) = auxSigResRejServ; %cost related to the remaining Pres
                                        tempAccepRatioPri(k,1) = ((numNonCSPri - numRejServPri)/numNonCSPri)*100; %computation of AR
                                        tempRejectSerPri(k,1) = numRejServPri; %number of rejected services
                                        tempPowerDemandNonRejSevPri(k,:) = powNonRejServPri; %power consumed according the services processed
                                    end
                                end
                                
                                %--- Total cost related to rejection per Combination of Variations of
                                %services
                                tempTotalCostRejServPri = tempCostRejServPri + tempCostResPowPri; %temporal total cost related to rejection
                                %tempTotalCostRejServ =
                                %tempCostRejServ + tempCostResPow
                                
                                %Sorted information of all analysis of non-rejectable services
                                [tempCostRejPri,indTempCosRejPri] = sort(tempTotalCostRejServPri); %The best value is the first in the list
                                
                                %Information of AR for services of different priority
                                infARNonRejSerPri = tempAccepRatioPri(indTempCosRejPri(1,1),1);
                                
                                %Information of cost for services of different priority
                                infCosNonRejSerPri = tempTotalCostRejServPri(indTempCosRejPri(1,1),1);
                                
                                %Information of rejected services of different priority
                                infRejServNonRejSerPri = tempRejectSerPri(indTempCosRejPri(1,1),1);
                                
                                %Information of power consumed for services of different priority
                                infConsumPowNonRejSerPri = tempPowerDemandNonRejSevPri(indTempCosRejPri(1,1),:);
                                
                                %Updated information of available power
                                remainPowerNCSPri = availablePowNCSPri - infConsumPowNonRejSerPri; %power demanded by non-critical services per priority
                                availablePowNCSPri = remainPowerNCSPri; %available power for non critical services
                                availablePowNCSPri(availablePowNCSPri<0)=0; %to ensure only possitive values
                                
                                %Cummulative information of rejected
                                %services
                                countRejServPri = countRejServPri + infRejServNonRejSerPri;
                                
                                %Cummulative information of power consumed
                                totPowComNonRejSerPri = totPowComNonRejSerPri + infConsumPowNonRejSerPri;
                                
                                
                            end
                            
                        else %Analysis of rejectable services
                            %disp('All services within this priority can be processed');
                            
                            %Update power demanded for NCS per priority
                            totPowComNonRejSerPri = totPowComNonRejSerPri + powNCSPri;
                            
                            
                            %Update of the available power
                            availablePowNCSPri = remainPowerNCSPri; %available power for non critical services
                            availablePowNCSPri(availablePowNCSPri<0)=0; %to ensure only possitive values
                            continue;
                            
                        end
                        
                        
                        
                    end
                    
                    %Metrics for rejection of services with different
                    %priorities
                    
                    %Information of AR for services of different priority
                    infARNonRejSer = ((inN - countRejServPri)/inN)*100;
                    outARCombVar(i,1) = infARNonRejSer;
                    
                    %Information of cost for services of equal priority
                    infCosNonRejSer = countRejServPri*1000; %1000 per each non-processed service
                    outCostCombVar(i,1) = infCosNonRejSer;
                    
                    %Information of power consumed for services of equal priority
                    infConsumPowNonRejSer = totPowComNonRejSerPri;
                    outPowCombVar(i,:) = infConsumPowNonRejSer;
                    
                else
                    %disp('There is no power for NCS');
                    
                    %Information of AR for services of equal priority
                    infARNonRejSer = ((inN - numNonCS)/inN)*100
                    outARCombVar(i,1) = infARNonRejSer;
                    
                    %Information of cost for services of equal priority
                    infCosNonRejSer = numNonCS*1000; %1000 per each non-processed service
                    outCostCombVar(i,1) = infCosNonRejSer;
                    
                    %Information of power consumed for services of equal priority
                    infConsumPowNonRejSer = powCS;
                    outPowCombVar(i,:) = infConsumPowNonRejSer;
                end
                
                
            end
            
        end
        
        %----------------------------------------------------------------------
        %--- Combinations of variations with positive residual power
    else
        %disp('Possitive combination of variations of services');
        outARCombVar(i,1) = 100; %Information of Acceptance Ratio
        outCostCombVar(i,1) = 0; %Information of cost related to acceptance ratio
        outPowCombVar(i,:) = inConsumedPowerComb(i,:); %Final power consumed per combination
    end
    
end

end


%--------------------------------------------------------------------------
%------ Function for computing the acceptance ratio and the cost related
%per combination of variations of services considering priority
%Greedy approach based on a recursive method inspired in a knapsack problem
%--- Input parameters:
%inNumRowCombVar: Number of variations of services
%inResPowCombVar: Residual information of combination of variations
%inCombVar: Information of Combination of variations
%inN: Number of variations per combination
%inTmax: Maximum time horizon
%inPes: Information of Pes
%inTpes: Time window related to Pes
%inPriorVarInfo: Priority of variations of service
%inPowVarServ: Power of variations of service
%inConsumedPowerComb: Consumed power per combination
%--- Out parameters:
%arCombVar: Acceptance ratio combination of variations of services
%outCostCombVar: Cost related to rejected service (acceptance ratio)
%outPowCombVar: Power consumed by only the processed services
%Example 1:
%[arCombVar,costCombVar,powCombVar] = funcARCostCombVarSerRec(numRowCombVar,...
%    resPowCombVar,combVar,n,tmax,Pes,tpes,priorVarInfo,powVarServ,consumedPowerComb);
%Example 3:
%[arInitCombVar,costARInitCombVar,powInitCombVar] = funcARCostCombVarSerRec(numRowInitCombVar,...
%    resPowInitCombVar,initCombVar,n,tmax,Pes,tpes,initPriorVarInfo,initPowVarServ,consumedPowerInitCombVar);

function [outARCombVar,outCostCombVar,outPowCombVar] = funcARCostCombVarSerRec(inNumRowCombVar,...
    inResPowCombVar,inCombVar,inN,inTmax,inPes,inTpes,inPriorVarInfo,...
    inPowVarServ,inConsumedPowerComb)

outARCombVar = zeros(inNumRowCombVar,1); %Acceptance ration of combinations of variations
outCostCombVar = zeros(inNumRowCombVar,1); %Cost of combinations of variations
outPowCombVar = zeros(inNumRowCombVar,inTmax); %Power of combinations of variations

for i = 1:inNumRowCombVar %exploration of all combinations
    
    %----------------------------------------------------------------------
    %--- Combinations of variations with negative residual power
    %The cost of each service that cannot be processed will be 1000(big M)
    if (find(inResPowCombVar(i,:)<0) > 0)
        %disp('Negative combination of variations of services');
        
        %--- Services that compose the negative combination of variations
        auxNegServCombVar = inCombVar(i,:);
        
        %--- Priority info of the services that compose the negative
        %combination of variations
        auxPriorNegSerCombVar = inPriorVarInfo(1,auxNegServCombVar);
        
        %--- Processing of negative combination of variations with different
        %priorities in services
        %This method can be also applied if the services have different
        %priorities
        availablePowCombServPri = inPes; %variable to store the information of the available power
        
        %Sort service priorities from the highest (1) to the lowest (n)
        [sortAuxPrior,indSortAuxPrior] = sort(auxPriorNegSerCombVar);
        
        %Services of the combination of variations sorted according
        %priorities in descending order of priority
        sortAuxreject = auxNegServCombVar(1,indSortAuxPrior);
        
        %Possible values of priority for NCS
        valuesPrior = sort(unique(sortAuxPrior));
        
        countRejServPri = 0; %counter of NCS rejected services in the priority analysis
        auxPowComNonRejServPri = zeros(1,length(inPes)); %variable to store the consumed power according the increase in priority
        totPowComNonRejSerPri = zeros(1,length(inPes)); %variable to store the consumed power
        
        for j = 1:length(valuesPrior) %analysis per priorities
            
            %Information of services within the combination of variations
            %according to priority which they belong to
            combVarServPri = [];
            combVarServPri = sortAuxreject(1,find(sortAuxPrior==valuesPrior(j)));
            numCombVarServPri = length(combVarServPri); %number of Comb of Variation per priority
            
            %Power of variations of service according priority
            auxPowCombVarServPri = inPowVarServ(combVarServPri,:);
            
            %Total power consumed by services per priority
            powCombVarSerPri = sum(auxPowCombVarServPri,1); %power demanded
            remainPowCombVarSerPri = availablePowCombServPri - powCombVarSerPri; %power demanded by non-critical services
            
            if find(remainPowCombVarSerPri(1,:) < 0)
                %disp('At least a service must be rejected within this priority');
                
                %Condition if there is no available power
                if length(find(availablePowCombServPri==0)) == length(availablePowCombServPri)
                    %disp('There no exist power in the system');
                    
                    countRejServPri = countRejServPri + numCombVarServPri; %add rejected service to all rejected services
                    auxPowComNonRejServPri = zeros(1,length(availablePowCombServPri));
                    auxPresCombNonRejServPri = availablePowCombServPri - auxPowComNonRejServPri;
                    availablePowCombServPri = auxPresCombNonRejServPri;
                    totPowComNonRejSerPri = totPowComNonRejSerPri + auxPowComNonRejServPri; %cummulative consumed power
                    continue;
                end
                
                %Condition if there exist available power and the services
                %must be rejected
                if numCombVarServPri == 1 %If only one service the power is not sufficient
                    
                    countRejServPri = countRejServPri + numCombVarServPri; %add 1 rejected service to all rejected services
                    auxPowComNonRejServPri = zeros(1,length(availablePowCombServPri));
                    auxPresCombNonRejServPri = availablePowCombServPri - auxPowComNonRejServPri;
                    availablePowCombServPri = auxPresCombNonRejServPri;
                    totPowComNonRejSerPri = totPowComNonRejSerPri + auxPowComNonRejServPri; %cummulative consumed power
                    continue;
                    
                else %one or more services can be rerejeted
                    
                    numAcceptServ = 0; %information about accepted services
                    powDemandeServ = []; %power demanded by services
                    
                    %First evaluation of residual power of services
                    initValPres = availablePowCombServPri - inPowVarServ(combVarServPri,:);
                    [rInitValPres,cInitValPres] = find(initValPres < 0);
                    
                    %Initial rejected services (Id information - no combVar
                    %Id because it can be different)
                    initRejectServ = unique(rInitValPres)'; %information of rejected services
                    %service whose indivial power overcomes the Pes
                    
                    numInitRejServ = length(initRejectServ); %number of initial rejected services
                    %countRejServPri = countRejServPri + numInitRejServ; %rejected service first evaluation
                    
                    %If the initial rejectable service is the total number
                    %of services per prioriry, all these services are
                    %rejected
                    if numInitRejServ == numCombVarServPri
                        countRejServPri = countRejServPri + numInitRejServ;
                        auxPowComNonRejServPri = zeros(1,length(availablePowCombServPri));
                        auxPresCombNonRejServPri = availablePowCombServPri - auxPowComNonRejServPri;
                        availablePowCombServPri = auxPresCombNonRejServPri;
                        totPowComNonRejSerPri = totPowComNonRejSerPri + auxPowComNonRejServPri; %cummulative consumed power
                        continue;
                        
                    else
                        
                        %Rest of services whose individual power is lower or equal that Pes (Id information
                        %no Id combVar because it can be different
                        processComVarServ = combVarServPri;
                        processComVarServ(initRejectServ) = []; %non-rejected initial services
                        [rProcessComVarServ, cProcessComVarServ] = size(processComVarServ);
                        
                        numRestRejServ = 0; %number of rejected services
                        
                        %Sorting variations of services according the consumed power (residual
                        %power in ascending order, from the lower to the higher, in order to
                        %process as much services as possible
                        %More resiudual power means a lower (smaller) power demand
                        
                        %Evaluation of residual power of the rest of variations
                        valPresResServ = sum(availablePowCombServPri - inPowVarServ(processComVarServ,:),2);
                        
                        %Auxiliar variable to define the sort method
                        auxPowVarServ = sum(inPowVarServ(processComVarServ,:),2);
                        auxMeanPowVarServ = mean(auxPowVarServ); %mean value of Pd of services
                        %Number of rows (services) lower than the mean value
                        auxLowVal = length(find(auxPowVarServ <= auxMeanPowVarServ));
                        auxHighVal = length(find(auxPowVarServ > auxMeanPowVarServ));
                        
                        if auxLowVal > auxHighVal
                            [valSortPresResServ,indSortPresResServ] = sort(valPresResServ,'descend');
                        else
                            [valSortPresResServ,indSortPresResServ] = sort(valPresResServ);
                        end
                        
                        %Information of services according the power consumed from lower to
                        %higher
                        sortProcessComVarServ = processComVarServ(indSortPresResServ');
                        
                        PesServ = availablePowCombServPri; %Information of available power
                        
                        for k = 1:cProcessComVarServ
                            
                            %Power for each service
                            auxPowServ = inPowVarServ(sortProcessComVarServ(k),:);
                            auxPresServ = PesServ - auxPowServ;
                            
                            if find(auxPresServ(1,:)<0) > 0
                                %disp('Rejected service');
                                numRestRejServ = numRestRejServ + 1;
                            else
                                %disp('Accepted service');
                                numAcceptServ = numAcceptServ + 1; %number of processed services
                                PesServ = auxPresServ; %update information of available Pes
                                powDemandeServ = [powDemandeServ; auxPowServ]; %power demande by services
                            end
                            
                        end
                        
                        countRejServPri = countRejServPri + numInitRejServ + numRestRejServ;
                        powCombVarSerPri = sum(powDemandeServ,1);
                        auxPresCombNonRejServPri = availablePowCombServPri - powCombVarSerPri;
                        availablePowCombServPri = auxPresCombNonRejServPri;
                        totPowComNonRejSerPri = totPowComNonRejSerPri + powCombVarSerPri; %cummulative consumed power
                        
                    end
                    
                end
                
            else
                %disp('All services within this priority can be processed');
                %Update power demanded for combinations of variations per priority
                totPowComNonRejSerPri = totPowComNonRejSerPri + powCombVarSerPri;
                
                %Update of the available power
                availablePowCombServPri = remainPowCombVarSerPri; %available power for non critical services
                availablePowCombServPri(availablePowCombServPri<0)=0; %to ensure only possitive values
                continue;
                
            end
            
        end
        
        %--- Result of metrics if the combination of variations of services
        %has a negative residual power, and considering different
        %priorities
        
        %Information of AR for services of different priority
        infARNonRejSer = ((inN - countRejServPri)/inN)*100;
        outARCombVar(i,1) = infARNonRejSer;
        
        %Information of cost for services of equal priority
        infCosNonRejSer = countRejServPri*1000; %1000 per each non-processed service
        outCostCombVar(i,1) = infCosNonRejSer;
        
        %Information of power consumed for services of equal priority
        infConsumPowNonRejSer = totPowComNonRejSerPri;
        outPowCombVar(i,:) = infConsumPowNonRejSer;
        
        %----------------------------------------------------------------------
        %--- Combinations of variations with positive residual power
    else
        %disp('Possitive combination of variations of services');
        outARCombVar(i,1) = 100; %Information of Acceptance Ratio
        outCostCombVar(i,1) = 0; %Information of cost related to acceptance ratio
        outPowCombVar(i,:) = inConsumedPowerComb(i,:); %Final power consumed per combination
        
    end
    
end

end


%--------------------------------------------------------------------------
%------ Function for computing the final metrics: NormPres and Plack
%--- Input parameters:
%inPes: Power from energy supplier
%inTpes: Time window related to Pes
%inPowCombVar: Real Power consumed after the allocation of services
%inARComVar: Acceptance ratio ralted to real allocation of services
%inTmax: Maximum time horizon
%inResPowCombVar: Theoretical residual power if all services are processed
%--- Out parameters:
%outNormResPowCombVar: Normalized residual power of combinations
%outNormPlackCombVar: Normalized missing power of combinations
%Example: [normResPowCombVar,normPlackCombVar] = funcCompMetric(Pes,tpes,powCombVar,ARCombVar,tmax,resPowCombVar)

function [outNormResPowCombVar,outNormPlackCombVar] = funcCompMetric(inPes,...
    inTpes,inPowCombVar,inARComVar,inTmax,inResPowCombVar)

auxNumComVar = length(inARComVar); %number of combinations of variations
outNormResPowCombVar = zeros(auxNumComVar,1); %normalized residual power
outNormPlackCombVar = zeros(auxNumComVar,1); %normalized missing power

for i = 1:auxNumComVar
    
    resPowCombVar = inPes - inPowCombVar(i,:); %real residual power of initial combination of services
    
    %--- Computation of missing power (Plack) related only to the best(real) combination of
    %variations of services
    if inARComVar(i) == 100
        plackCombVar = zeros(1,inTmax);
    else
        theorResPowCombVar = inResPowCombVar(i,:); %theoretical value of residual power if all variations of services would be processed
        theorResPowCombVar(theorResPowCombVar>0)=0;
        plackCombVar = theorResPowCombVar * (-1);
    end
    
    %--- Mean values of metrics
    avPes = sum(inPes)/inTpes; %mean value of power from energy supplier
    avResPowCombVar = sum(resPowCombVar)/inTpes; %mean value of residual power
    avPlackCombVar = sum(plackCombVar)/inTpes; %mean value of lack power
    
    %---Normalized values of metrics
    outNormResPowCombVar(i) = avResPowCombVar/avPes; %nomalized value of residual power
    outNormPlackCombVar(i) = avPlackCombVar/avPes; %nomalized value of missing power
    
end

end


%--------------------------------------------------------------------------
%------ Function for computing the inividual costs and total cost, and the
%AR, real power demanded  and NormPres and NormPlack of combinations
%(chromosomes in the context of the genetic algorithm)
%This is the function to perform the fitness of the solutions
%--- Input parameters:
%inN: Number of services
%inCombVar: Combinations of variatiosn (chromosomes)
%inNumRowCombVar: Number of rows of combinations
%inNumColCombVar: Number of columns of combinatios
%inTmax: Maximum time horizon
%inPowVarServ: Information of power of variation of services
%inPriorVarInfo: Information about the priority of variations of services
%inMtsVarInfo: Information about the time interval of variations
%inPes: Power from energy suplier
%inTpes: Time variable related to the power from energy supplier

%--- Out parameters:
%outCostLkCombVar: Cost of priority of combinations of varations
%outCostMkCombVar: Cost of time shifting of combinations of varations
%outCostARCombVar: Cost of rejection of a service(s) of combinations
%outARCombVar: Acceptance ratio value of service(s) that can be processed
%outPowCombVar: Power consumed by the service(s) that can be processed
%outTotCostComVar: Total cost considering the three metrics

%Example: [costLkCombVar,costMkCombVar,costARCombVar,arCombVar,powCombVar,...
%    totCostComVar,normResPowCombVar,normPlackCombVar] = funcCompCostComVar(n,...
%    combVar,numRowCombVar,numColCombVar,tmax,powVarServ,priorVarInfo,...
%    mtsVarInfo,Pes,tpes);

function [outCostLkCombVar,outCostMkCombVar,outCostARCombVar,...
    outARCombVar,outPowCombVar,outTotCostComVar,outNormResPowCombVar,...
    outNormPlackCombVar] = funcCompCostComVar(inN,inCombVar,...
    inNumRowCombVar,inNumColCombVar,inTmax,inPowVarServ,inPriorVarInfo,...
    inMtsVarInfo,inPes,inTpes)

%--- Cost related to the priority level: cl
costLk = inPriorVarInfo'; %the corresponds to priority level

%--- Cost related to the time shifting performed: cmts
costMk = inMtsVarInfo'; %the cost corresponds to the time shifting value

%--- Consumed power of variations of services
consumedPowerComb = zeros(inNumRowCombVar,inTmax);

%--- Cost related to the priority level (cl) of combinations of variations
costLkCombVar = zeros(inNumRowCombVar,1);

%--- Cost related to the time shifting performed (cmts) of combinations of variations
costMkCombVar = zeros(inNumRowCombVar,1);

for i = 1:inNumRowCombVar % i number of combinations
    %consumedPower(i,:) = demandPower(combinations(i,1),:) + ...
    %    demandPower(combinations(i,2),:) + demandPower(combinations(i,3),:);
    
    aux = zeros(1,inTmax); %auxiliar variable to store the current power of each variation
    auxCostLk = 0; %auxiliar variable to store the priority information of a variation
    auxCostMts = 0; %auxiliar variable to store the time shifting of a variation
    consumedPowerComb(i,:) = zeros(1,inTmax); %power consumer per combination of variations
    costLkCombVar(i,1) = 0; %cost of priority per combination of variations
    costMkCombVar(i,1) = 0; %cost of time shifting per combination of variations
    
    for j = 1:inNumColCombVar %i number of columns of combinations
        aux = inPowVarServ(inCombVar(i,j),:); %current value of a variation
        auxCostLk = costLk(inCombVar(i,j),1); %current value of priority
        auxCostMts = costMk(inCombVar(i,j),1); %current value of time shifting
        consumedPowerComb(i,:) = consumedPowerComb(i,:) + aux;
        costLkCombVar(i,1) = costLkCombVar(i,1) + auxCostLk;
        costMkCombVar(i,1) = costMkCombVar(i,1) + auxCostMts;
    end
    
end

outCostLkCombVar = costLkCombVar; %cost of priority
outCostMkCombVar = costMkCombVar; %cost of time shifting

%--- Residual power of combinations of variations (chromosomes)
resPowCombVar = zeros(inNumRowCombVar,inTmax);

for i = 1:inNumRowCombVar % i number of combinations
    resPowCombVar(i,:) = inPes - consumedPowerComb(i,:);
end

%--- AR, cost related and power demanded by the processed services
% [arCombVar,costARCombVar,powCombVar] = funcARCostCombVarSer(inNumRowCombVar,...
%     resPowCombVar,inCombVar,inN,inTmax,inPes,inTpes,inPriorVarInfo,...
%     inPowVarServ,consumedPowerComb);
[arCombVar,costARCombVar,powCombVar] = funcARCostCombVarSerRec(inNumRowCombVar,...
    resPowCombVar,inCombVar,inN,inTmax,inPes,inTpes,inPriorVarInfo,...
    inPowVarServ,consumedPowerComb);

outCostARCombVar = costARCombVar; %cost of rejection
outARCombVar = arCombVar; %acceptance ration of combination of services (chromosomes)
outPowCombVar = powCombVar; %power demanded by combination of services

%--- Total cost of combinations of variations of services
totCostComVar = costLkCombVar + costMkCombVar + costARCombVar;
outTotCostComVar = totCostComVar;

%--- Normalized Pres and Plack values of the processed services
[outNormResPowCombVar,outNormPlackCombVar] = funcCompMetric(inPes,inTpes,...
    outPowCombVar,outARCombVar,inTmax,resPowCombVar);

end


%--------------------------------------------------------------------------
%------ Function for the allocation of services considering the
%minimization of Pres, Greedy implementation
%--- Input parameters:
%Pes: Information about the available power
%tpes: Time variable were the Pes is different to zero
%n: Number of services
%initVarInfo: Information of variations if MTs = 0
%tinitVarInfo: Initial time of services without MTs applied
%initPriorVarInfo: Information of priority of original services
%initPowVarServ: Power demanded by the original services
%varInfo: Information of variations of services
%priorVarInfo: Priority of variations of services
%mtsVarInfo: Time shifting information of variation of services
%powVarServ: Power demanded by the variation of services
%processServ: Information of processed services within the combination
%proccessedVarServ: Information of processed variation within combination

%--- Out parameters:
%costLkBestCombVar: Cost related to the Lk in the solution
%costMkBestCombVar: Cost related to the MTs in the solution
%costARBestCombVar: Cost related to AR in the solution
%totCostBestComVar: Total cost of the solution
%powDemandServInfo: Power demanded by the processed services
%normResPowCombVar: Normalized Pres
%arCombVar: AR value
%normPlackCombVar: Normalized Plack

%Example: [costLkBestCombVar,costMkBestCombVar,costARBestCombVar,totCostBestComVar,...
%    powDemandServInfo,normResPowCombVar,arCombVar,normPlackCombVar,...
%    processServ,proccessedVarServ] = funcGreedyDRAlloc(Pes,...
%    tpes,n,initVarInfo,tinitVarInfo,initPriorVarInfo,initPowVarServ,varInfo,priorVarInfo,mtsVarInfo,powVarServ)

function [costLkBestCombVar,costMkBestCombVar,costARBestCombVar,totCostBestComVar,...
    powDemandServInfo,normResPowCombVar,arCombVar,normPlackCombVar,...
    processServ,proccessedVarServ] = funcGreedyDRAlloc(Pes,tpes,n,initVarInfo,...
    tinitVarInfo,initPriorVarInfo,initPowVarServ,varInfo,priorVarInfo,mtsVarInfo,powVarServ)

%Services constrained to the available capacity and execution time
%-Minimum Pres and as much as possible
%-Consideration of time shifting

infoPrioServ = unique(initPriorVarInfo);

PesAvServ = Pes; %available power in the system
auxTinitPes = find(PesAvServ>0);
tiniPesAvServ = auxTinitPes(1); %initial time of Pes

numPriorServ = length(infoPrioServ);
powDemandServInfo = zeros(1,length(Pes)); %variable to store the consumed power
%by the combination of variation that can be processed
rejectServInfo = 0; %variabble to store the information of rejected service
proccessedVarServ = []; %variable to store the information of the processed variation service(s)
processServ = []; %information of accepted service
nonProcServ = []; %information of rejected service

for i = 1:numPriorServ
    
    %--- Information of services per priority
    auxInfoServPrior = initVarInfo(1,find(initPriorVarInfo == infoPrioServ(1,i)));
    [rAuxInfoServPrior, cAuxInfoServPrior] = size(auxInfoServPrior);
    %disp(auxInfoServPrior);
    
    %If the system has no energy all services within the priority are
    %rejected
    if PesAvServ == 0
        %disp('All services in this category can be processed');
        servInfoPrior = (find(services(:,2) == i))';
        rejectServInfo = rejectServInfo + length(servInfoPrior);
        continue;
    end
    
   %****** Delete
%     %If all services within this priority have no energy for their
%     %processing
%     if PesAvServ == 0
%         %disp('All services in this category can be processed');
%         rejectServInfo = rejectServInfo + rNegPresServPrio;
%         continue;
%     end
    %******
    
    %--- Sorting the services in descending order according their power
    %consumed (values) from the lower to the higher.
    %This consideration has been stablished because in order to process as
    %much services as possible
    %Another option is to sort from the highest residual power to the
    %lowest
    auxPowDemandServPrior = initPowVarServ(auxInfoServPrior,:);
    auxTinitVarInfo = tinitVarInfo(1,auxInfoServPrior);
    
    %--- Evaluation of the first service per category (Mts = 0)
    %Accordint two parameters:
    %It is better a lower consumed power (higher Pres, after allocation)
    %It is better the services that starts first, because it helps to
    %contribute to allocate subsequent services
    auxPresServPrior = PesAvServ - auxPowDemandServPrior; %residual power of services per priority
    [rNegPresServPrio, cNegPresServPrio] = find(auxPresServPrior < 0);
    rNegPresServPrio = unique(rNegPresServPrio); %service with (Mts = 0) and negative Pres
    
    auxPresServPrior(auxPresServPrior<0)=0; %to ensure only positive values
    auxTotPresServ = sum(auxPresServPrior,2);
    %i) A greater residual power means that the power demanded is lower
    %This is more suitable because it is according to the conditions of
    %the system
    %ii) It is better a service that starts first, because it give the
    %oportunity to allocate the rest of demands
    paraSelecAuxServ = [auxTotPresServ, auxTinitVarInfo']; %parameters Pres info and tinitk info
    [valSortAuxPresServ,indSortAuxPresServ] = sortrows(paraSelecAuxServ,[-1,2]);
    sortAuxInfoServPrior = auxInfoServPrior(1,indSortAuxPresServ);
    
    %--- Selection of the first service and its best variation
    %bestServ = sortAuxInfoServPrior(1);
    
    %--- Computation of power and rejected service of services per priority
    %Analysis of each service (variations of services) per priority
    for j = 1:cAuxInfoServPrior
        
        auxServInfo = sortAuxInfoServPrior(1,j); %information of service
        infoVarServ = find(varInfo == auxServInfo); %information of variations per service
        numVarServ = length(infoVarServ); %number of variation per service
        %disp(infoVarServ); %information of variation per service
        
        %Information about the time shifting performd by the variations of services
        tsVarInfo = (mtsVarInfo(1,infoVarServ))';
        
        %Information of consumed power per variation of services
        powVarSerInfo = powVarServ(infoVarServ,:); %power of variations
        presVarSerInfo = PesAvServ - powVarSerInfo; %residual power of variations
        [rPresVarSerInfo, cPresVarSerInfo] = find(presVarSerInfo < 0); %row and column of negative Pres
        negPresVarSerInfo = unique(rPresVarSerInfo)';
        numNegPresVarSerInfo = length(negPresVarSerInfo);
        
        auxPresGradient = presVarSerInfo(:,tiniPesAvServ:tiniPesAvServ + (tpes-1)); %variable to compute the gradient
        
        if numNegPresVarSerInfo > 0
            %disp('There exist variation(s) that produce negative Pres');
            
            if numNegPresVarSerInfo == numVarServ
                %disp('This service should be rejected');
                rejectServInfo = rejectServInfo + 1; %It is 1 because it corresponds to
                %to the analysis of a single
                %service
                nonProcServ = [nonProcServ,auxServInfo];
                continue;
            else
                infoVarServ(negPresVarSerInfo) = []; %delete the invalid variations
                presVarSerInfo(negPresVarSerInfo,:) = []; %Pres of valid variations
                totPresVarInfo = sum(presVarSerInfo,2); %total Pres per variation
                
                tsVarInfo(negPresVarSerInfo) = []; %mTs of valid combinations
                totCostPresMts = tsVarInfo + totPresVarInfo; %total cost of variation
                
                auxPresGradient(negPresVarSerInfo,:) = []; %info gradient, valid variations
                presGradient = gradient(auxPresGradient);
                totPresGradVarInfo = sum(presGradient,2); %total gradient
            end
            
        else
            %disp('All the variations are valid variations');
            totPresVarInfo = sum(presVarSerInfo,2); %total Pres per variation
            totCostPresMts = tsVarInfo + totPresVarInfo; %total cost of variation
            
            presGradient = gradient(auxPresGradient);
            totPresGradVarInfo = sum(presGradient,2); %total gradient
        end
        
        %--- Parameter to select the best variation
        %1) The variation that produce the minimum Pres (minimum cost)
        %2) Evaluation of gradient. A greater value is better to facilitate the
        %allocation of a next service
        paramSelecVarSer = [totCostPresMts,totPresGradVarInfo];
        [ValParSelecVarSer, indParSelecVarSer] = sortrows(paramSelecVarSer,[1,-2]);
        
        sortInfoVarServ = infoVarServ(indParSelecVarSer); %information of variation sorted
        selectVarServ = sortInfoVarServ(1,1); %the best variation
        
        %--- Information of service processed
        processServ = [processServ,auxServInfo];
        
        %--- Information of the variation processed
        proccessedVarServ = [proccessedVarServ,selectVarServ];
        %disp(proccessedVarServ);
        
        
        %Allocation of energy and update of available power
        powSelecVarSer = powVarServ(selectVarServ,:);
        powDemandServInfo = powDemandServInfo + powSelecVarSer; %cummulative power
        remainderPower = PesAvServ - powSelecVarSer; %residual power for the next variation
        
        PesAvServ = remainderPower; %update of available power in the system
        PesAvServ(PesAvServ<0)=0; %to ensure only possitive values
    end
    
end

%Information processed services
%disp('Proccessed services');
%disp(processServ);

%Information of unprocessed services
%disp('Un-proccessed services');
%disp(nonProcServ);
numNonProcServ = length(nonProcServ);

%Information of variations processed
%disp('Processed variations');
%disp(proccessedVarServ);


%--- Information of priority costs related to the solution (best combination)
auxCostLk = priorVarInfo(1,proccessedVarServ);
costLkBestCombVar = sum(auxCostLk,2); %total cost related to priority

%--- Information of time shifting costs related to the solution (best combination)
auxtMk = mtsVarInfo(1,proccessedVarServ);
costMkBestCombVar = sum(auxtMk,2); %total cost related to time displacement


%--- Computation of final metrics

%--- Pres metric
presCombVar = Pes - powDemandServInfo;
presCombVar(presCombVar<0)=0;
%presCombVar = [0     0     0     1     0     0];

%--- AR metric
arCombVar = ((n - rejectServInfo)/n)*100;

%--- Information of AR costs related to the solution (best combination)
costARBestCombVar = rejectServInfo * 1000;

%--- Total cost of the solution (best combination)
totCostBestComVar = costLkBestCombVar + costMkBestCombVar + costARBestCombVar;

PresAvServ = presCombVar; %variable to store the information of Pres after
%allocation of services
plackCombVar = zeros(1,length(Pes)); %variable to store the lack power (real)
%in the current conditions of the system

%--- Computation of Pres for the computation of Plack
if arCombVar < 100
    %disp('Plack > 0, the system need more energy to process all demands');
    
    if sum(presCombVar,2) == 0
        %disp('The plack is the sum of power of non-processed services');
        auxPowNonProcServ = initPowVarServ(nonProcServ,:);
        plackCombVar = sum(auxPowNonProcServ,1);
    else
        %disp('The correct Plack should be computed in the current conditions');
        
        for i = 1:numNonProcServ
            auxNonProcServInfo = nonProcServ(1,i); %information of non-processed services
            infoNonProcVarServ = find(varInfo == auxNonProcServInfo); %information of variations per service
            
            %Information of consumed power per variation of services
            powVarNonProcSerInfo = powVarServ(infoNonProcVarServ,:); %power of variations
            %presNonProcVarSerInfo = PresAvServ - powVarSerInfo; %residual power of variations
            presNonProcVarSerInfo = PresAvServ - powVarNonProcSerInfo; %residual power of variations
            presNonProcVarSerInfo(presNonProcVarSerInfo > 0) = 0; %evaluation of negative values
            totpresNonProcVarSerInfo = sum(presNonProcVarSerInfo,2); %total Pres per variation
            [valSortNonProcVarSer,indSorNonProcVarSer] = sort(totpresNonProcVarSerInfo,'descend');
            
            selecNonProcVarSer = infoNonProcVarServ(1,indSorNonProcVarSer(1)); %non-process service
            powSelecNonProVarSer = powVarServ(selecNonProcVarSer,:);
            presSelecNonProVarSer = PresAvServ - powSelecNonProVarSer; %Pres considering the service
            %non-processed
            %service
            auxPlackNonProVarSer = presSelecNonProVarSer;
            auxPlackNonProVarSer(auxPlackNonProVarSer > 0) = 0;
            plackNonProVarSer = auxPlackNonProVarSer * (-1);
            plackCombVar = plackCombVar + plackNonProVarSer; %information of Plack
            
            PresAvServ = presSelecNonProVarSer; %updated information of available Pres
            PresAvServ(PresAvServ<0)=0; %to ensure only possitive values
        end
    end
    
else
    %disp('All processed services');
    plackCombVar = zeros(1,length(Pes));
end

%--- Mean values of metrics
avPes = sum(Pes)/tpes; %mean value of power from energy supplier
avResPowCombVar = sum(presCombVar)/tpes; %mean value of residual power
avPlackCombVar = sum(plackCombVar)/tpes; %mean value of lack power

%---Normalized values of metrics
normResPowCombVar = avResPowCombVar/avPes; %nomalized value of residual power
normPlackCombVar = avPlackCombVar/avPes; %nomalized value of missing power

end


% --- Function to store data, compatible with parfor instruction
%par_Case = [iterTd,iterTs,normResPow,normResPowPosVal,...
%normResPowNegVal,bestAR];
function parsave(fname,iterTd,iterTs,normResPowBestCombVar,arBestCombVar,...
    normPlackBestCombVar)
par_Case = [iterTd,iterTs,normResPowBestCombVar,arBestCombVar,normPlackBestCombVar];
save(fname, 'par_Case')
end